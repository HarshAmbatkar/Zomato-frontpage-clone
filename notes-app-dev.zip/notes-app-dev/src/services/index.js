export {addNote, editNote, getNotes} from "./noteService";
export {addToTrash, restoreFromTrash, deleteFromTrash} from "./trashService";
export {addToArchive, restoreFromArchive} from "./archiveService";

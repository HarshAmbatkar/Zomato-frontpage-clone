const isLabelInNote = (noteLabels, label) => {
  return noteLabels.includes(label);
};

export {isLabelInNote};

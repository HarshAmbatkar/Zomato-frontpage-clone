export { default as defaultUser } from './default_user.png';
export { default as defaultHeader } from './default_header.png';
export { default as pageNotFound } from './404_page.svg';
